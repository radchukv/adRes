#' Export functions
#'
#' @importFrom binom binom.confint
#' @export
binom::binom.confint

NULL
